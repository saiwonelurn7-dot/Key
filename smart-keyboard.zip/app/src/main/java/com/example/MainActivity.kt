package com.example

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        SetupScreen()
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SetupScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    var testText by remember { mutableStateOf("") }
    
    val bgMain = Color(0xFFF3F5F7)
    val cardWhite = Color.White
    val cardBlue = Color(0xFFD9E2FF)
    val cardDark = Color(0xFF0F172A)
    val cardGreen = Color(0xFFE8F5E9)
    val textDark = Color(0xFF1A1C1E)
    
    Scaffold(
        modifier = modifier,
        containerColor = bgMain,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 20.dp)
                    .windowInsetsPadding(WindowInsets.statusBars),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Smart Keyboard", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = textDark, letterSpacing = (-0.5).sp)
                    Text("v2.4.0 • Active", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color(0xFF2563EB))
                }
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .shadow(2.dp, CircleShape)
                        .clip(CircleShape)
                        .background(Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color(0xFF475569), modifier = Modifier.size(20.dp))
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .padding(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Row 1: Welcome (Large) + Step 1 (Square)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Welcome Card
                BentoCard(
                    modifier = Modifier.weight(1.2f).fillMaxHeight(),
                    backgroundColor = cardWhite
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFFDBEAFE)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("ကခ", color = Color(0xFF2563EB), fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("Languages", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = textDark)
                            Text("4 Active Packs", fontSize = 12.sp, color = Color(0xFF64748B))
                        }
                    }
                }
                
                // Step 1 Card
                BentoCard(
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                    backgroundColor = cardBlue,
                    onClick = { context.startActivity(Intent(android.provider.Settings.ACTION_INPUT_METHOD_SETTINGS)) }
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Step 1", fontWeight = FontWeight.Bold, color = Color(0xFF1E293B))
                        Text("Enable\nKeyboard", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E293B))
                    }
                }
            }
            
            // Row 2: Privacy (Small wide) + Step 2 (Square)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Column of two small cards for the left side
                Column(
                    modifier = Modifier.weight(1.2f).fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    BentoCard(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        backgroundColor = cardGreen
                    ) {
                        Row(
                            modifier = Modifier.fillMaxSize(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF15803D), modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Local Data", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF166534))
                            }
                        }
                    }
                    
                    BentoCard(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        backgroundColor = cardDark
                    ) {
                        Row(
                            modifier = Modifier.fillMaxSize(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Smart Predict ✨", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
                
                // Step 2 Card
                BentoCard(
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                    backgroundColor = cardWhite,
                    onClick = { imm.showInputMethodPicker() }
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Step 2", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF64748B))
                        Text("Select\nKeyboard", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = textDark)
                    }
                }
            }
            
            // Row 3: Test Text Field
            BentoCard(
                modifier = Modifier.fillMaxWidth().weight(1f),
                backgroundColor = cardWhite
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    Text("Try it out", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = textDark)
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = testText,
                        onValueChange = { testText = it },
                        placeholder = { Text("Type here...") },
                        modifier = Modifier.fillMaxSize(),
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedBorderColor = Color(0xFFE2E8F0),
                            focusedBorderColor = Color(0xFF2563EB),
                            unfocusedContainerColor = Color(0xFFF8FAFC),
                            focusedContainerColor = Color(0xFFF8FAFC)
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun BentoCard(
    modifier: Modifier = Modifier,
    backgroundColor: Color,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(24.dp)
    var boxModifier = modifier
        .shadow(1.dp, shape, spotColor = Color(0x0D000000), ambientColor = Color(0x0D000000))
        .clip(shape)
        .background(backgroundColor)
        .border(1.dp, Color(0xFFF1F5F9), shape)
        
    if (onClick != null) {
        Box(
            modifier = boxModifier.clickable { onClick() }.padding(20.dp),
            content = content
        )
    } else {
        Box(
            modifier = boxModifier.padding(20.dp),
            content = content
        )
    }
}
