package com.example.ui.keyboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.KeyboardCapslock
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.SpaceBar
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun KeyboardScreen(
    onKeyPress: (String) -> Unit,
    onBackspace: () -> Unit,
    onEnter: () -> Unit
) {
    var isShifted by remember { mutableStateOf(false) }
    var currentLanguageIndex by remember { mutableStateOf(0) }
    val languages = KeyboardLanguage.values()
    val currentLanguage = languages[currentLanguageIndex]

    val layout = when (currentLanguage) {
        KeyboardLanguage.ENGLISH -> if (isShifted) Layouts.englishShiftedLayout else Layouts.englishLayout
        KeyboardLanguage.MYANMAR -> if (isShifted) Layouts.myanmarShiftedLayout else Layouts.myanmarLayout
        KeyboardLanguage.SHAN -> if (isShifted) Layouts.shanShiftedLayout else Layouts.shanLayout
        KeyboardLanguage.THAI -> if (isShifted) Layouts.thaiShiftedLayout else Layouts.thaiLayout
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(vertical = 8.dp)
    ) {
        layout.forEach { row ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                row.forEach { keyLabel ->
                    KeyItem(
                        label = keyLabel,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            onKeyPress(keyLabel)
                            if (isShifted) isShifted = false // Auto un-shift after a key is pressed, if not caps lock
                        }
                    )
                }
            }
        }

        // Action Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            ActionKeyItem(
                icon = Icons.Default.KeyboardCapslock,
                modifier = Modifier.weight(1.5f),
                isToggled = isShifted,
                onClick = { isShifted = !isShifted }
            )
            ActionKeyItem(
                icon = Icons.Default.Language,
                modifier = Modifier.weight(1.5f),
                onClick = {
                    currentLanguageIndex = (currentLanguageIndex + 1) % languages.size
                }
            )
            KeyItem(
                label = currentLanguage.displayName,
                modifier = Modifier.weight(4f),
                onClick = { onKeyPress(" ") } // Spacebar
            )
            ActionKeyItem(
                icon = Icons.AutoMirrored.Filled.Backspace,
                modifier = Modifier.weight(1.5f),
                onClick = { onBackspace() }
            )
            KeyItem(
                label = "↵",
                modifier = Modifier.weight(1.5f),
                onClick = { onEnter() },
                color = MaterialTheme.colorScheme.primaryContainer
            )
        }
    }
}

@Composable
fun KeyItem(
    label: String,
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.surface,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .padding(2.dp)
            .height(54.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(color)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 20.sp,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun ActionKeyItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    isToggled: Boolean = false,
    onClick: () -> Unit
) {
    val backgroundColor = if (isToggled) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
    val iconColor = if (isToggled) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
    Box(
        modifier = modifier
            .padding(2.dp)
            .height(54.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(backgroundColor)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = iconColor
        )
    }
}
