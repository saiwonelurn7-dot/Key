package com.example.ui.keyboard

enum class KeyboardLanguage(val displayName: String) {
    ENGLISH("English"),
    MYANMAR("မြန်မာ"),
    SHAN("Shan"),
    THAI("ไทย")
}

enum class ActionType {
    SHIFT, BACKSPACE, SWITCH_LANGUAGE, SPACE, ENTER, NUMBERS, SYMBOLS
}

object Layouts {
    val englishLayout = listOf(
        listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
        listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"),
        listOf("z", "x", "c", "v", "b", "n", "m")
    )
    
    val englishShiftedLayout = listOf(
        listOf("Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"),
        listOf("A", "S", "D", "F", "G", "H", "J", "K", "L"),
        listOf("Z", "X", "C", "V", "B", "N", "M")
    )
    
    val myanmarLayout = listOf(
        listOf("ဆ", "တ", "န", "မ", "အ", "ပ", "က", "င", "သ", "စ"),
        listOf("ေ", "ျ", "ိ", "်", "ါ", "့", "ြ", "ု", "ူ"),
        listOf("ဖ", "ထ", "ခ", "လ", "ဘ", "ည", "ာ")
    )
    
    val myanmarShiftedLayout = listOf(
        listOf("ဈ", "ဝ", "ဣ", "၎", "ဤ", "၌", "ဥ", "၍", "ဪ", "ဋ္ဌ"),
        listOf("ှ", "ဂ", "ရ", "စ", "လ", "ဘ", "ည", "ယ", "ဒ"),
        listOf("ဇ", "ဌ", "ဃ", "ဠ", "ᎎ", "ဉ", "ဍ")
    )
    
    val shanLayout = listOf(
        listOf("ၸ", "တ", "ၼ", "မ", "ဢ", "ပ", "ၵ", "င", "သ", "စ"),
        listOf("ႁ", "ꧤ", "ရ", "လ", "ဝ", "ၺ", "ယ", "ꧦ", "ꧠ"),
        listOf("ၽ", "ထ", "ၶ", "ꧡ", "ꧢ", "ꧣ", "ꧤ")
    )
    
    val shanShiftedLayout = shanLayout
    
    val thaiLayout = listOf(
        listOf("ๆ", "ไ", "ำ", "พ", "ะ", "ั", "ี", "ร", "น", "ย", "บ", "ล"),
        listOf("ฟ", "ห", "ก", "ด", "เ", "้", "่", "า", "ส", "ว", "ง"),
        listOf("ผ", "ป", "แ", "อ", "ิ", "ื", "ท", "ม", "ใ", "ฝ")
    )
    val thaiShiftedLayout = thaiLayout
}
